/*
* CKEditor Email Plugin
*
* @author Washington County Webteam <webteam@co.washington.or.us>
* @version 1.0.0
*/
(function ($, Drupal) {
	CKEDITOR.plugins.add('email', {
		init: function (editor) {
      CKEDITOR.dialog.add('email', CKEDITOR.getUrl(this.path + 'dialogs/email.js'));
			editor.addCommand('email', new CKEDITOR.dialogCommand('email', {
				allowedContent: 'div{*}(*); a[*]; img[*]'
      }));
      editor.addContentsCss(this.path + 'styles/widget.css');

      editor.widgets.add('email_widget', {
        upcast: function (element) {
          return element.name === 'span' && element.hasClass('cke-email');
        },
        // List editable areas here.
        editables: {
          body: {
            selector: 'a'
          }
        },
        requiredContent: 'span(cke-email)',
        allowedContent: 'img',
        dialog: 'email'
      });

			editor.ui.addButton('Email', {
				label : 'Insert Email',
				toolbar : 'insert',
				command : 'email',
				icon : this.path + 'images/icon.png'
			});


		}
	});

})(jQuery, Drupal);
