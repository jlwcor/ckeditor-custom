/**
 * @file
 * Provide email dialog.
 */

(function ($, Drupal, CKEDITOR) {

  'use strict';

  CKEDITOR.dialog.add('email', function (editor) {

    return {
      title: 'Insert Email',
      minWidth: 510,
      minHeight: 200,
      contents:
        [{
          id: 'emailPlugin',
          expand: true,
          elements:
            [
              {
                id: 'pmail',
                type: 'text',
                width: '100%',
                label: "Email: ",
                validate: CKEDITOR.dialog.validate.notEmpty("Email cannot be empty."),
                setup: function (widget) {
                  //grab email and set in dialog.
                  var element = $('<div>').append(widget.element.getHtml());
                  var pmail = $(element).find('a').attr("href");

                  pmail = pmail ? pmail.split("mailto:") : '';
                  pmail = pmail[1] ? pmail[1] : '';

                  var dialog = CKEDITOR.dialog.getCurrent();
                  var titleField = dialog.getContentElement('emailPlugin', 'pmail').setValue(pmail);
                }
              }
            ]
        }
        ],
      onOk: function () {
        var content = '';

        var pmail = this.getValueOf('emailPlugin', 'pmail') || 'test@test.com';

        content += '<span class="cke-email"><a href="mailto:' + pmail + '">' + pmail + '</a></span>';

        var element = CKEDITOR.dom.element.createFromHtml(content);

        //reset stored values
        pmail = '';

        editor.insertElement(element);
        editor.widgets.initOn(element, 'email_widget');


      },
      buttons: [CKEDITOR.dialog.cancelButton, CKEDITOR.dialog.okButton]
    };
  });

})(jQuery, Drupal, CKEDITOR);
