/**
 * @file
 * Provide alert dialog.
 */

(function ($, Drupal, CKEDITOR) {

  'use strict';

  CKEDITOR.dialog.add('alert', function (editor) {

    return {
      title: 'Insert an Inline Alert',
      minWidth: 510,
      minHeight: 200,
      contents:
        [{
          id: 'alertPlugin',
          expand: true,
          elements:
            [
              {
                id: 'title',
                type: 'text',
                width: '100%',
                label: "Title: ",
                setup: function (widget) {
                  //grab title and set in dialog.
                  var element = $('<div>').append(widget.element.getHtml());
                  var title = $(element).find('div.alert-title').text();

                  var dialog = CKEDITOR.dialog.getCurrent();
                  var titleField = dialog.getContentElement('alertPlugin', 'title').setValue(title);
                }
              },
              {
                id: 'body',
                type: 'textarea',
                className: 'hidden',
                setup: function (widget) {
                  //grab title and set in dialog.
                  var element = $('<div>').append(widget.element.getHtml());
                  var body = $(element).find('div.alert-body').html();

                  var dialog = CKEDITOR.dialog.getCurrent();
                  var bodyField = dialog.getContentElement('alertPlugin', 'body').setValue(body);
                }
              },
              {
                type: 'select',
                id: 'type',
                label: 'Select your inline alert type:',
                items: [['faded-blue'], ['faded-gray'], ['faded-red']],
                'default': 'faded-blue',
                setup: function (widget) {
                  //grab field and set in dialog.
                  var element = $('<div>').append(widget.element.getHtml());
                  var type = $(element).find('div.alert').attr('class').split(/\s+/);
                  $.each(type, function (index, item) {
                    if (item.match("^bg-")) {
                      type = item.split('bg-')[1];
                    }
                  });

                  var dialog = CKEDITOR.dialog.getCurrent();
                  var typeField = dialog.getContentElement('alertPlugin', 'type').setValue(type);
                }
              }
            ]
        }
        ],
      onOk: function () {
        var content = '';

        var title = this.getValueOf('alertPlugin', 'title') || '';
        var body = this.getValueOf('alertPlugin', 'body') || 'Insert body here...';
        var type = this.getValueOf('alertPlugin', 'type') || 'primary';

        content += '<div class="cke-alert">';
        content += '<div class="alert bg-' + type + '" role="alert">';
        content += '<div class="alert-title"><h2 class="h4">' + title + '</h2></div>';
        content += '<div class="alert-body">' + body + '</div>';
        content += '</div>';
        content += '</div>';

        var element = CKEDITOR.dom.element.createFromHtml(content);

        //reset stored values
        title = '';

        editor.insertElement(element);
        editor.widgets.initOn(element, 'alert_widget');


      },
      buttons: [CKEDITOR.dialog.cancelButton, CKEDITOR.dialog.okButton]
    };
  });

})(jQuery, Drupal, CKEDITOR);
