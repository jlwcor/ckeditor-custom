/*
* CKEditor Alert Plugin
*
* @author Washington County Webteam <webteam@co.washington.or.us>
* @version 1.0.0
*/
(function ($, Drupal) {
	CKEDITOR.plugins.add('alert', {
		init: function (editor) {
      CKEDITOR.dialog.add('alert', CKEDITOR.getUrl(this.path + 'dialogs/alert.js'));
			editor.addCommand('alert', new CKEDITOR.dialogCommand('alert', {
				allowedContent: 'div{*}(*); a[*]; img[*]'
      }));
      editor.addContentsCss(this.path + 'styles/widget.css');

      editor.widgets.add('alert_widget', {
        upcast: function (element) {
          return element.name === 'div' && element.hasClass('cke-alert');
        },
        // List editable areas here.
        editables: {
          body: {
            selector: '.alert-body'
          }
        },
        requiredContent: 'div(cke-alert)',
        allowedContent: 'img',
        dialog: 'alert'
      });

			editor.ui.addButton('Alert', {
				label : 'Insert Inline Alert',
				toolbar : 'insert',
				command : 'alert',
				icon : this.path + 'images/icon.png'
			});


		}
	});

})(jQuery, Drupal);
